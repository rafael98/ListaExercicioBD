
# \\\\\\\\\ questão 3- certo \\\\\\\\\\\\\\\\\

DELIMITER $$ 
create procedure TotalClientes(out codigocliente int)
begin

Select * from cliente
order by nomecliente;

END$$
DELIMITER ;

CALL TotalClientes(@a);

# \\\\\\\\\\\\\questão 4- certo \\\\\\\\\\\\\\\

DELIMITER $$ 
create procedure BaratosProdutos(inout codigoproduto integer)
begin

select * from produto
where precounitario < 1.50;

END$$
DELIMITER ;


set @valor = 3.00;
CALL BaratosProdutos(@valor);

# \\\\\\\\\\ questão 5 - certo \\\\\\\\\\\\\\\ 

DELIMITER $$ 
create procedure VendasProdutos(inout codigoproduto integer)
begin

select * from produto
where precounitario < 1.50;

END$$
DELIMITER ;


call VendasProdutos(@valor);

# \\\\\\\\\\\\\\ questão 6 - certo  \\\\\\\\\\

DELIMITER $$ 
create procedure ProdutoSP 
(p_codigoproduto integer, p_unidade character(3), p_descricaoproduto varchar(30), p_precounitario real )

main: BEGIN

if (p_codigoproduto = '') then
select 'ERRO: o campo nao pode ficar vazio' as msg;
leave main;
end if;
 
 if(p_unidade = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if;
 
 if (p_descricaoproduto = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if; 
 
 if (p_precounitario = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if;
 
 insert into produto (codigoproduto, unidade, descricaoproduto, precounitario )
 values
 (p_codigoproduto, p_unidade, p_descricaoproduto, p_precounitario);
 

END$$
DELIMITER ; 


CALL ProdutoSP('58','','','2.19');

select * from produto;

# \\\\\\\\\\\\\\ questão 7 - \\\\\\\\\\


CALL ProdutoSP('58','kg','Arroz','2.19');
CALL ProdutoSP('50','M','Fralda','5.05');
CALL ProdutoSP('10','','','1.19');
