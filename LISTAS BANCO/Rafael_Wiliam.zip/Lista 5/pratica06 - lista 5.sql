#questão 1 -
create database pratica06;

use pratica06;

# questão 2 -

create table exemplo1 (
c1 integer not null,
c2 integer,
c3 integer,
c4 integer
);



# questão 4 - "o tempo de execução foi de  0.188 sec "
select * from exemplo1 where c3 = 4801 and c2 = 4899 and c4= 4750;

#----------------------------------------------------------------

#questão 5 e 6 - criação dos indices c2,c3,c4 
create index idx_c2 on exemplo1(c2);

create index idx_c3 on exemplo1(c3);

create index idx_c4 on exemplo1(c4);

## antes do  comando analyze o tempo de execução foi de 0.110sec 
select * from exemplo1 where c3 = 4801 and c2 = 4899 and c4= 4750;

## depois do  comando analyze o tempo de execução foi 0.000sec
analyze table exemplo1;

select * from exemplo1 where c3 = 4801 and c2 = 4899 and c4= 4750;

#-----------------------------------------------------------------

#questão 7 - campo c1

select * from exemplo1 where c1 = 5020;

# tempo de execução: 0.203sec
#-----------------------------------------------------------------

#questão 7 - campo c2

select * from exemplo1 where c2 = 5020;

#tempo de execução 0.047sec

#------------------------------------------------------------------





















