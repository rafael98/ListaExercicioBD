			####### LISTA 1 - Respostas (questão 1,2 e 3 são orientações)############

#/// quesão 4 - Certo ///
alter table cliente add email varchar(30) after endereco;

select * from cliente;


# /// questão 6 - Certo /// 

select numero_agencia, endereco, cod_banco from agencia
where cod_banco='1'
order by numero_agencia;

# /// questão 7 - ERRO DUPLICANDO DADOS ///

select numero_conta, num_agencia, nome
from cliente as c join historico as h
on c.cpf = h.cpf_cliente
join conta as x
on h.num_conta = x.numero_conta;


# /// questão 8 - Certo ///

select * from cliente 
where sexo= 'm'
order by nome;


# /// questão 9 - certo ///


select ag.numero_agencia, ag.endereco, b.codigo, b.nome 
from agencia as ag inner join banco as b
on (ag.cod_banco = b.codigo)
where numero_agencia ='0562';


select * from agencia;


# /// questão 10 - certo ///

delete from conta
where num_agencia = '3153';

select * from conta;


# /// questão 11 - certo /// 

update agencia set numero_agencia = 6342 where cod_banco = 4;

select * from agencia;

# /// questão 12- certo /// 

update cliente set email= 'caetanolima@gmail.com' where cpf = '666.777.888-99';

select * from cliente;


# ///questão 13- certo ///

select numero_conta,saldo, floor(saldo * 10/100 + 3879) as 'Valor total com aumento de 10%' from conta
where tipo_conta = '1';



               
               
               
               
               
               
