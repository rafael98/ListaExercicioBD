##questão 09- 
create database pratica05;

use pratica05;

## questão 10 - 
create table dados_multimidia (
codigo integer auto_increment not null,
nome varchar (30),
tipo varchar (20),
dados longblob,
primary key (codigo)
);

##questão 11- 
insert into dados_multimidia (nome,tipo,dados) 
values ('Rafael','Foto JPEG','D:\Faculdade- 2017\flamengo.jpgflamengo.jpg');

insert into dados_multimidia(nome,tipo,dados) 
values ('Rafael','Foto JPEG','D:\Faculdade- 2017\arroz.jpg');

insert into dados_multimidia(nome, tipo, dados)
values('Rafael','Foto JPEG','D:\Faculdade- 2017\brasil.jpg');

##questão 12- 
select * from dados_multimidia;

show variables like "secure_file_priv";
'secure_file_priv', 'C:\\ProgramData\\MySQL\\MySQL Server 5.7\\Uploads\\'


##questão 13 - 

select dados INTO dumpfile 'D:\\Faculdade- 2017\\imagem_export1.jpg' from dados_multimidia where codigo = 1;
select dados INTO dumpfile 'D:\\Faculdade- 2017\\imagem_export2.jpg' from dados_multimidia where codigo = 2;
select dados INTO dumpfile 'D:\\Faculdade- 2017\\imagem_export3.jpg' from dados_multimidia where codigo = 3;
