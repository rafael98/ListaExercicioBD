   ################## LISTA 2 - Respostas ###################

#  \\\ questão 3- \\\

create view estudantes_portugues as select nome, matricula
from estudante as es   inner join  cursa as c 
on (c.matricula_est = es.matricula)
where c.cod_disc = '2';


# \\\ questão 4 - \\\

select * from estudantes_portugues;

# \\\ questão 5 - \\\

create table log_funcionario(
cpf_func varchar(15) null,
comando varchar (15) NULL,
usuario varchar (20)NULL,
data_hora date
);

# \\\ questão 6 - \\\

DELIMITER $$
USE `escola`$$
CREATE DEFINER = CURRENT_USER TRIGGER `escola`.`tg_funcionario_UPDATE` AFTER UPDATE ON funcionario FOR EACH ROW
BEGIN
INSERT INTO log_funcionario
SET comando = 'UPDATE',
cpf_func = OLD.cpf,
usuario = CURRENT_USER,
data_hora= now();
END$$
DELIMITER ;

# \\\ questão 7 - \\\

update funcionario set nome = 'Ricardo Pereira Alves' where cpf = '99988855520';

select * from funcionario;

# \\\ questão 8 - \\\

DELIMITER $$
USE `escola`$$
create definer = current_user trigger `escola`.`log_funcionario_INSERT` before insert on funcionario for each row
BEGIN
insert into log_funcionario
SET comando = 'INSERT',
cpf_func = new.cpf_func,
usuario = current_user,
data_hora= now();
END$$
DELIMITER ;

# \\\ questão 9 - \\\

insert into funcionario
(cpf, cargo, nome, endereco, telefone, data_nasc, data_admin, salario) 
values
('99988855520', 'Atendente', 'Pedro Augusto', 'Rua Perigrino ', '(12)3365-8875', '1978-09-29', '2002-03-10', '2500');

select * from log_funcionario;






